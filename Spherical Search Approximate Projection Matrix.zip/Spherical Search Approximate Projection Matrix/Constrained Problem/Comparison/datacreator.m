clc;
clear all;
%% data collection for calculation of score
eval = 'LASS_Ar2_temp_2017_';
for i = 1:4
    if i == 1
        eva = [eval,'10D_statistic.xlsx'];
    elseif i == 2
        eva = [eval,'30D_statistic.xlsx'];
    elseif i == 3
        eva = [eval,'50D_statistic.xlsx'];
    else
        eva = [eval,'100D_statistic.xlsx'];
    end
    A = xlsread(eva,1);
    xlswrite('SASS-AP.xlsx',A,i)
end