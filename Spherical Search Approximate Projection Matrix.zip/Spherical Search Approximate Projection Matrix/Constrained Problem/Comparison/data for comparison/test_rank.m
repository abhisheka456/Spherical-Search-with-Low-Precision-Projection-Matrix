function rank = test_rank(A,B,C)
l = size(A,1);

[rank] = rankWithDuplicates(A,'descend');
for i = 1:l
    rr = find(rank == i);
    b = [];
    b = B(rr);
    [rank1] = rankWithDuplicates(b);
    rank(rr) = rank(rr)+rank1-1;
end

for j = 1:l
    rr = find(rank == j);
    b = [];
    b = C(rr);
    [rank1] = rankWithDuplicates(b);
    rank(rr) = rank(rr)+rank1-1;
end
rank = rank';