function rank = test_rank2(A,B)
l = size(A,1);

[rank] = rankWithDuplicates(A);
for i = 1:l
    rr = find(rank == i);
    b = [];
    b = B(rr);
    [rank1] = rankWithDuplicates(b);
    rank(rr) = rank(rr)+rank1-1;
end

rank = rank';