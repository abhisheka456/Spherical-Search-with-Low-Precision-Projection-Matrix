function [data, state] = signedranktest(A,B)
[m,n] = size(A);
[m1,n1] = size(B);
if m==m1||n==n1
else
    error('size of both sample is different');
end
data = zeros(n,5);
W = 0;
L = 0;
Eq = 0;
for i = 1:n
    a = (A(:,i));
    b = (B(:,i));
    d = a-b;
    dd = abs(a-b);
    R = tiedrank(dd);
    Iplus = find(d > 0);
    Iminus = find(d < 0);
    Iequal = find(d == 0);
    Rplus = sum(R(Iplus))+0.5*sum(R(Iequal));
    Rminus = sum(R(Iminus))+0.5*sum(R(Iequal));
    [p,h] = signrank(a,b,'alpha',0.05);
    data(i,:) = [i Rplus Rminus p 0];
    if (h == 1)&(Rplus < Rminus)
        W = W+1;
        data(i,5) = 1;
    elseif (h == 1)&(Rplus > Rminus)
        L = L+1;
        data(i,5) = -1;
    elseif h == 0
        Eq = Eq+1;
        data(i,5) = 0;
    end
   
end
state = [W Eq L];
end