function [fit1,alpha] = alpha_cal(f,c)
f1 = f(:);
c1 = c(:);
f2 = f1';
c2 = c1';
ff = f1(:,ones(1,length(f)))-f2(ones(length(f),1),:);
cc = c1(:,ones(1,length(f)))-c2(ones(length(f),1),:);

tt = -ff./cc;
tt(tt<0|tt==inf|tt==-inf) = 0;
al = max(tt,[],2);
% al(find(al==inf)) = 0;
% a1(find(al==-inf)) = 0;
alpha = max(al)+1e-16;
fit1 = f+alpha*c;

end
