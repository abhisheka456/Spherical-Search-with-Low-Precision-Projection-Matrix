function rank = rank_mean(A,B,C)
[m,n] = size(A);
rank = zeros(m,n);
for i = 1:n
    a = A(:,i);
    b = B(:,i);
    c = C(:,i);
    rnk = test_rank(a,b,c);
    rank(:,i)=rnk;
end
end

