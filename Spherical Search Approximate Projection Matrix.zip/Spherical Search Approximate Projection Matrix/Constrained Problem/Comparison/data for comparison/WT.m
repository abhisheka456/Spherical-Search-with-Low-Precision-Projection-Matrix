clc;
clear all;
%% formation of Matrix A, B, C, D,E,F
A = [];
B = [];
C = [];
D = [];
E = [];
F = [];
for i = 1:6
    if i == 1
        eva = 'SASS-AP.xlsx';
    elseif i == 2
        eva = 'IUDE.xlsx';
    elseif i == 3
        eva = 'ilSHADE_epsilon.xlsx';
    elseif i == 4
        eva = 'eMAgES.xlsx';
    elseif i == 5
        eva = 'CORCO.xlsx';
    else
        eva = 'DECODE.xlsx';
    end
    data = xlsread(eva,1);
    B = [B;data(9,:)];
    C = [C;data(5,:)];
end
%% Friedman Ranking
[~,~,F] = Statistical_Test(C,B); %F = round(F,7);
for i = 1
    result = [];
    for j = i+1:6
        Iplus = sum(F(:,i) < F(:,j));
        Imin  = sum(F(:,i) > F(:,j));
        Iequal = 28-Iplus-Imin;
        result = [result;Iplus,Iequal,Imin];
    end
 eva = ['LASS_' num2str(i) '=result;']; eval(eva);   
end