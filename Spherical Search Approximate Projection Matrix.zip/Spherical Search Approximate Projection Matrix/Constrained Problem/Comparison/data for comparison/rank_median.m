function rank = rank_median(A,B)
[m,n] = size(A);
rank = zeros(m,n);
for i = 1:n
    a = A(:,i);
    b = B(:,i);
    rnk = test_rank2(a,b);
    rank(:,i)=rnk;
end
end
