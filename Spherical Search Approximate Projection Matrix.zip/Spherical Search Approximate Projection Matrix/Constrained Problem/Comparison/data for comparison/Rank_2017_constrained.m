clc;
clear all;
%% formation of Matrix A, B, C, D,E,F
A = [];
B = [];
C = [];
D = [];
E = [];
F = [];
for i = 1:6
    if i == 1
        eva = 'SASS-AP.xlsx';
    elseif i == 2
        eva = 'IUDE.xlsx';
    elseif i == 3
        eva = 'ilSHADE_epsilon.xlsx';
    elseif i == 4
        eva = 'eMAgES.xlsx';
    elseif i == 5
        eva = 'CORCO.xlsx';
    else
        eva = 'DECODE.xlsx';
    end
    data = xlsread(eva,4);
    A = [A;data(8,:)];
    B = [B;data(9,:)];
    C = [C;data(5,:)];
    D = [D;data(4,:)];
    E = [E;data(2,:)];
end
%% mean rank
mean_r = rank_mean(A,B,C);
%% median rank
med_r = rank_median(D,E);

tmean_r = sum(mean_r,2);
tmed_r = sum(med_r,2);
total_r = tmean_r+tmed_r;
[~,ii] = sort(total_r);
Rank(ii) = (1:6)'; 
%% Friedman Ranking
[FR,~,F] = Statistical_Test(C,B);
%% data formation
Data = zeros(28,20);
ii = 2*(1:6);
jj = ii-1;
Data(:,jj) = C';
Data(:,ii) = B';
[~,Bold] = sort(F,2);
%% statistic;
data = [tmean_r,tmed_r,total_r,Rank'];