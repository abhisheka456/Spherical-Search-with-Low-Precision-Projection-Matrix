function [rank,WT,F] = Statistical_Test(A,B)
%% calculate fitness value
[m,n] = size(A);
% n: number of problems
% m: number of algorithms
F = zeros(n,m);
for i = 1:n
    k = B(:,i) == 0;
    F(i,k) = A(k,i)';
    if ~isempty(max(A(k,i)))
        F(i,~k) = max(A(k,i)) + B(~k,i)';
    else
        F(i,:) = B(:,i)';
    end

end
%% remove problems 17,19,26, and 28
% F([17,19,26,28],:) = [];
rank = myfriedman(F)/n;
%% wilcoxon Test
for i = 1:m-1
    [data, state] = signedranktest(F(:,m),F(:,i));
    WT(i,:) = [i,data(2:4)];
end
end