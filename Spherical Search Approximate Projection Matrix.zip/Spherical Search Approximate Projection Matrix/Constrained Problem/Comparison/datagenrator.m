clc;
clear all;
filename = 'LASS_Ar2_temp_2017_100D_statistic.xlsx';
AA = xlsread(filename,1);
BB = xlsread('others_sol.xlsx',4);
F1 = AA(5,:)';
C1 = AA(9,:)';
F2 = BB(:,1);
C2 = BB(:,2);
F3 = BB(:,3);
C3 = BB(:,4);
F4 = BB(:,5);
C4 = BB(:,6);
F5 = BB(:,7);
C5 = BB(:,8);
F6 = BB(:,9);
C6 = BB(:,10);
Fit1 = F1+ 1e100*C1;
Fit2 = F2+ 1e100*C2;
Fit3 = F3+ 1e100*C3;
Fit4 = F4+ 1e100*C4;
Fit5 = F5+ 1e100*C5;
Fit6 = F6+ 1e100*C6;
A = zeros(28,5);
%% + sign
A(Fit1 < Fit2,1) = 1;
A(Fit1 < Fit3,2) = 1;
A(Fit1 < Fit4,3) = 1;
A(Fit1 < Fit5,4) = 1;
A(Fit1 < Fit6,5) = 1;
%% - sign
A(Fit1 > Fit2,1) = -1;
A(Fit1 > Fit3,2) = -1;
A(Fit1 > Fit4,3) = -1;
A(Fit1 > Fit5,4) = -1;
A(Fit1 > Fit6,5) = -1;
%% calculation
B = [F1,C1,F2,C2,A(:,1),F3, C3,A(:,2),F4,C4,A(:,3),F5,C5,A(:,4),F6,C6,A(:,5)];
%% bold sign
C = tiedrank([Fit1,Fit2,Fit3,Fit4,Fit5,Fit6]')';
%% 
xlswrite(filename,B,2);
xlswrite(filename,C,3);