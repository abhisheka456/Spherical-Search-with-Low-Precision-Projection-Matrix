function  [p,objF,conV,FES]=repair_mlm(x,objF,conV,minVar,maxVar,problem,FES)
% global X gen
% [popsize,n]=size(p);
% for i = 1:popsize
%     if conV(i) > 0 && rand < X && rem(gen,n) == 0
%% formulation for MLM
        n             = length(x);
        xold          = x;
        [~,~, gg, hh] = fitness(x,problem);
        fhd           = @objf;
        if isempty(gg)
           x0        = x(:);
        else
           x0        = [x(:); sqrt(max(0,-gg(:)))];
        end
        options.maxiter    = 3;
        options.display    = 0;
        options.D          = n;
        prob.xmin          = minVar(:);
        prob.xmax          = maxVar(:);
        prob.I_fno         = problem;
        prob.constr_fun_name = @fitness;
        prob.n             = n;
        prob.gn(problem)   = length(gg);
        prob.hn(problem)   = length(hh);
        [x,~,FE] = MLM(fhd,x0,options,prob);
        FES = FES+FE;
        if sum(real(x) ~= x)
           x = x0(1:n);
        else
           x = x(1:n)';
           ii = find(x < prob.xmin');
           x(ii) = prob.xmin(ii);
           ii = find(x > prob.xmax');
           x(ii) = prob.xmax(ii);
           [ff, cc, ~, ~] = fitness(x,problem);
        if conV > cc
           p    = x;
           objF = ff;
           conV = cc;
        else
           p    = xold;
        end
        end
%     end
% end
end

%% other functions
function [x,y,FE] = MLM(fhd,x0,opt,problem)
lambda = 0.01;
I = eye(length(x0));
Z = zeros(length(x0),1);
x = x0;
F = feval(fhd,x,problem);
J = Jocob_MAT(x,problem);
FE = opt.D+1;
%% stopping criteria parameters
tolF    = 1e-25;
tolX    = 1e-12;
sqrtEps = sqrt(eps);
tolOpt  = 1e-4*tolF;
relFactor = max(norm(J.'*F,inf),sqrtEps);
%% iteration parameter
it = 0;
tol = 1e-25;
stop = 0;
flag  = 0;
while (stop == 0)
d  = [J;sqrt(lambda)*I]\[F;Z];
trialx1 = x-d;
trialF1 = feval(fhd,trialx1,problem);
FE      = FE+1;
d2      = [J;sqrt(lambda)*I]\[trialF1;Z];
trialx2 = x-d-d2;
trialF2 = feval(fhd,trialx2,problem);
FE      = FE+1;
d3      = [J;sqrt(lambda)*I]\[trialF2;Z];
trialx  = x-d-d2-d3;
trialF  = feval(fhd,trialx,problem);
FE      = FE+1;
if norm(trialF) < norm(F)
    if flag == 0
        lambda = lambda/10;
    end
    x = trialx;
    oldF = F;
    F = trialF;
    J = Jocob_MAT(x,problem);
    FE = FE+opt.D;
    flag = 0;
    it = it+1;

%% stopping criteria
    if (abs(F'*F-oldF'*oldF) < tolF*(oldF'*oldF))||( it > opt.maxiter)|| (norm(d+d2+d3) < tolX*(sqrtEps+norm(x))) || (norm(J'*F,inf) < tolOpt*relFactor) || (flag > 10)
        stop = 1;
    end


if opt.display == 1
    disp([num2str(it),'    m=', num2str(lambda), '------> ', num2str(max(norm(F)^2)),' TolF = ',num2str(norm(J'*F,inf)), ' TolX = ', num2str(norm(d))]);
end
else
    flag = flag + 1;
    lambda = 10*lambda;
end

if (flag > 10)||( it > opt.maxiter)
        stop = 1;
end
end

y = norm(F);
end


function f = objf(xx,problem)
x             = xx(1:problem.n);
gb            = xx(problem.n+1:end); gb = gb(:);
[~,~,g,h] = feval(problem.constr_fun_name,x',problem.I_fno);
g = g(:)+gb.^2;
% g  = max(0,g);
if problem.gn(problem.I_fno) == 0
    f = [h(:)];
elseif problem.hn(problem.I_fno) == 0
    f = [g(:)];
else
f = [g(:);h(:)];
end
end

function J = Jocob_MAT(x,problem)
     fhd   = @objf;
     F     = feval(fhd,x,problem);
     confcn = {'','','','',''};
     nVar = numel(x);
     nfun = numel(F);
     options.DerivativeCheck = 'off';
     options.Diagnostics = 'off';
     options.DiffMaxChange = Inf;
     options.DiffMinChange = 0;
     options.Display = 'iter';
     options.FinDiffRelStep = sqrt(eps)*ones(nVar,1);
     options.FinDiffType = 'forward';
     options.FunValCheck = 'off';
     options.Jacobian = 'off';
     options.MaxFunEvals = 270000;
     options.MaxIter = 5000;
     options.OutputFcn = [];
     options.PlotFcns = [];
     options.TolFun = 1.0000e-06;
     options.TolFunValue = 1.0000e-25;
     options.TolX = 1.0000e-12;
     options.TypicalX= ones(nVar,1);
     options.UseParallel= 0;
     options.InitDamping = 0.0100;
     options.JacobMult = [];
     options.JacobPattern = 'sparse(ones(Jrows,Jcols))';
     options.MaxPCGIter = 'max(1,floor(numberOfVariables/2))';
     options.PrecondBandWidth = Inf;
     options.ScaleProblem = 'none';
     options.TolPCG = 0.1000;
     options.Algorithm = 'levenberg-marquardt';
     options.GradObj = 'off';
     options.GradConstr = 'off';
     
     

     finDiffFlags.fwdFinDiff= 1;
     finDiffFlags.scaleObjConstr= 0;
     finDiffFlags.chkComplexObj= 0;
     finDiffFlags.isGrad= 0;
     finDiffFlags.hasLBs= false(nVar,1);
     finDiffFlags.hasUBs= false(nVar,1);
     finDiffFlags.chkFunEval= 1;
     
     

    sizes.xShape = [nVar 1];
    sizes.nVar= nVar;
     J = zeros(nfun,nVar);
     funfcn = {'fun','fsolve',fhd,[],[]};
    [J,~,~,numEvals,evalOK] = computeFinDiffGradAndJac(x,funfcn,confcn,F, ...
        [],[],J,[],[],-Inf*ones(nVar,1),Inf*ones(nVar,1),[],options,finDiffFlags,sizes,problem);
end