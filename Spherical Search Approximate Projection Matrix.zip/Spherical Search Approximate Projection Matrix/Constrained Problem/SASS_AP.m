%% START FROM here
%% Self-Adaptive Spherical Search with A Low Precision Projection Matrix 
%%                for Real-WorldOp timization
%%    Abhishek Kumar, Swagatam Das, Lingping Kong, and Vaclav Snasel
%% -----------------------------------------------------------------------
clc;
clear all;
format long;
format compact;

for Dim = [10,30,50,100]
Max_NFES = 2*Dim*10000;
fhd = @fitness;

for func = 1:28
  I_fno = func;
  %% Define the bounds 
  [Xmin, Xmax] = problemSelection2017(func, Dim);
  lu = [Xmin ; Xmax];
  outcome = []; 

  fprintf('\n-------------------------------------------------------\n')
  fprintf('Function = %d, Dimension size = %d\n', func, Dim) 
  initial_flag = 0;
  Stat_All = zeros(25,5);
  
  for run_id = 1:25
        rand('seed', run_id*sum(100 * clock));
        run_funcvals = [];
        %%  parameter settings for SASS
        Pmax = 0.25;
        Pbest_Rate = Pmax;    
        Arc_Rate = 1.4;
        Mem_Size = 5;
        Pop_Size = 80;
        NFES = 0;
        %% Initialize the main population
        popold = repmat(lu(1, :), Pop_Size, 1) + rand(Pop_Size, Dim) .* (repmat(lu(2, :) - lu(1, :), Pop_Size, 1));
        pop = popold; 
        [fit, cons, ~, ~, ~] = feval(fhd,pop,func);
        
        bc_i_fit_var = 1e+30;
        bc_i_con_var = 1e+30;
        bc_i_index = 0;
        bc_i_solution = zeros(1, Dim);
        
        VAR0=max(cons)^3;         
        cp=(-log(VAR0)-6)/log(1-0.5);
        

        for i = 1 : Pop_Size
            NFES = NFES + 1;
            if (cons(i) < bc_i_con_var)||((cons(i) == bc_i_con_var && fit(i) <= bc_i_fit_var))
                bc_i_fit_var = fit(i);
                bc_i_con_var = cons(i);
                bc_i_solution = pop(i, :);
                bc_i_index = i;
            end
            
            if NFES > Max_NFES; break; end
        end

        
        Mem_c = 0.3 .* ones(Mem_Size, 1);
        Mem_r = 0.8 .* ones(Mem_Size, 1);
        
        Mem_Pos = 1;
        
        Arch.NP = floor(Arc_Rate * Pop_Size)+1; 
        Arch.pop = zeros(0, Dim); 
        Arch.funvalues = zeros(0, 1); 
        
        %% main loop
        gg=0;  
        igen =1;  
        
        X = 0;
        while NFES < Max_NFES
            gg=gg+1;
            if X < 0.5
                VAR=VAR0*(1-X)^cp;
            else
                VAR=0;
            end
            n = floor(Pop_Size/2);
            pop = popold; 
            sorted_index = sort_cons(fit, cons, 0);
            ks = sorted_index(1:n);
            Mem_Rand_IDX = ceil(Mem_Size * rand(Pop_Size, 1));
            MU_c = Mem_c(Mem_Rand_IDX);
            MU_r = Mem_r(Mem_Rand_IDX);
            
            PPOS = find(Mem_Rand_IDX==Mem_Size);
            MU_c(PPOS) = 0.9;
            MU_r(PPOS) = 0.9;
          
            r_i = normrnd(MU_r, 0.1);
            term_pos = find(MU_r < -1);
            r_i(term_pos) = 0;
            r_i = min(r_i, 1);
            r_i = max(r_i, 0);
            if(NFES <= Max_NFES/2)
                if rand < 0.5
                    c_i = 0.5*ones(Pop_Size,1);
                else
                    c_i = 0.1*rand(Pop_Size,1)+0.45;
                end
            else
            if NFES < 0.5*Max_NFES
                r_i = max(r_i, 0.75*exp(-(NFES/Max_NFES)^2));
            end
            
            c_i = MU_c + 0.1 * tan(pi * (rand(Pop_Size, 1) - 0.5));
            pos = find(c_i <= 0);
            
            while ~ isempty(pos)
                c_i(pos) = MU_c(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
                pos = find(c_i <= 0);
            end
            end
            
            c_i = min(c_i, 1);
            if NFES < 0.6*Max_NFES
               c_i = min(c_i,0.6*exp((NFES/Max_NFES).^3.5));
            end
              
            
            
            r0 = [1 : Pop_Size];
            popAll = [pop;Arch.pop];
            [r1, r2, r3] = gnR1R2(Pop_Size, size(popAll, 1), r0);
            r4 = floor(rand(Pop_Size,1)*Pop_Size)+1;
            pNP = max(round(Pbest_Rate * Pop_Size), 2); 
            randindex = ceil(rand(1, Pop_Size) .* pNP); 
            randindex = max(1, randindex); 
            pbest = pop(sorted_index(randindex), :); 
            

            if NFES < 0.4*Max_NFES
                scc = 0.6*exp(6*(NFES/Max_NFES).^3);
            else
                scc = 1.2;
            end
             
            %%
            tep = pbest;tep(ks,:)=pop(r3(ks),:);
            vi = pop(r0,:) + c_i(:, ones(1, Dim)) .* (scc.*(tep - pop(r0,:)) + pop(r1, :) - popAll(r2, :) + 0.5*(pop(r1, :) - pop(r0, :)));
            vi = boundConstraint(vi, pop, lu);
            II = eye(Dim);
            TM = II+1e-4*randn(Dim);
            PP = TM'./(norm(TM,1)*norm(TM,inf));
            for k = 1:3
                PP= PP*((TM*PP-2*II)*(TM*PP-II)+II);
            end
            TM_ = PP;
            Xr = pop*TM;
            vi = vi*TM;
            Ur = Xr;
            nn = size(Xr,2);
            J_= mod(floor(rand(Pop_Size, 1)*nn), nn) + 1;
            J = (J_-1)*Pop_Size + (1:Pop_Size)';
            r_is = rand(Pop_Size, nn) < r_i(:, ones(1, nn));
            Ur(J) = vi(J);
            Ur(r_is) = vi(r_is);
            ui = Ur*TM_;
              
            [Trail_Fit, Trail_ConV, ~, ~, ~] = feval(fhd, ui, func);
            for i = 1:Pop_Size
                if rand < 0.02 && Trail_ConV(i) > 0 && rem(gg,Dim) == 0
                   [ui(i,:),Trail_Fit(i),Trail_ConV(i),NFES] = repair_mlm(ui(i,:),Trail_Fit(i),Trail_ConV(i),Xmin,Xmax,func,NFES);
                end
            end
           

            I1 = zeros(Pop_Size,1);
            I2 = I1;
            for i = 1 : Pop_Size
                NFES = NFES + 1;
                if (Trail_ConV(i) < bc_i_con_var)||((Trail_ConV(i) == bc_i_con_var && Trail_Fit(i) <= bc_i_fit_var))
                    bc_i_fit_var = Trail_Fit(i);
                    bc_i_con_var = Trail_ConV(i);
                    bc_i_solution = ui(i, :);
                    bc_i_index = i;
                end
                if (Trail_ConV(i) < cons(i))||((Trail_ConV(i) == cons(i) && Trail_Fit(i) <= fit(i)))
                    I1(i) = 1;
                end
                if (max(0,Trail_ConV(i)-VAR) < max(0,cons(i)-VAR))||(max(0,Trail_ConV(i)-VAR) == max(0,cons(i)-VAR) && Trail_Fit(i) <= fit(i))
                    I2(i) = 1;
                end
                if NFES > Max_NFES; break; end
            end
            X = NFES/Max_NFES;
            %% selection
            dif = abs(fit-Trail_Fit);
            %% I == 1: the parent is better; I == 2: the offspring is better
            goodr_i = r_i(I1 == 1);
            goodF = c_i(I1 == 1);
            dif_val = max(0,dif(I1 == 1));
            

            Arch = updateArchive(Arch, popold(I2 == 1, :), fit(I2 == 1));
      
            popold = pop;
            popold(I2 == 1, :) = ui(I2 == 1, :);
            fit(I2 == 1, :) = Trail_Fit(I2 == 1, :);
            cons(I2 == 1, :) = Trail_ConV(I2 == 1, :);

            
            num_success_params = numel(goodr_i);
            
            if num_success_params > 0
                sum_dif = sum(dif_val);
                dif_val = dif_val / sum_dif;
                Mem_c(Mem_Pos) = ((dif_val' * (goodF .^ 2)) / (dif_val' * goodF)+Mem_c(Mem_Pos))*0.5;
                if max(goodr_i) == 0 || Mem_r(Mem_Pos)  == -1
                    Mem_r(Mem_Pos)  = -1;
                else
                    Mem_r(Mem_Pos) = ((dif_val' * (goodr_i .^ 2)) / (dif_val' * goodr_i)+Mem_r(Mem_Pos))*0.5;
                end
                Mem_Pos = Mem_Pos + 1;
                if Mem_Pos > Mem_Size;  Mem_Pos = 1; end
            end
            %% diversity enhancement
            if (std(cons) < 1e-8 && min(cons) > 0) || (std(fit) < 1e-7 && min(abs(fit)) > 1e-5)
               popold = repmat(lu(1, :), Pop_Size, 1) + rand(Pop_Size, Dim) .* (repmat(lu(2, :) - lu(1, :), Pop_Size, 1));
               pop = popold; % the old population becomes the current population
               [fit, cons, ~, ~, ~] = feval(fhd,pop,func);
               NFES = NFES + Pop_Size;
            end
            Pbest_Rate = Pmax*(1 - 0.5*NFES/Max_NFES);
        end
        if bc_i_fit_var < 1e-8
           bc_i_fit_var = 0;
        end
        bestF(run_id, func) = bc_i_fit_var;
        bestC(run_id, func) = bc_i_con_var;
        fprintf('%d th run, best-so-far [function value = %1.8e, Constraint Violation = %1.8e] \n', run_id , bc_i_fit_var, bc_i_con_var);
        [~,~,~,~,best_conV_range_num] = fitness(bc_i_solution, func);
        Stat_All(run_id,:) = [ bc_i_fit_var bc_i_con_var best_conV_range_num];
    end %% end 1 run
    Stat_F(func,:) = [min(bestF(:,func)) mean(bestF(:,func)) max(bestF(:,func)) std(bestF(:,func))];
    Stat_C(func,:) = [min(bestC(:,func)) mean(bestC(:,func)) max(bestC(:,func)) std(bestC(:,func))];
    disp(Stat_F(func,:));
    disp(Stat_C(func,:));
    % calculate the index of feasible solutions
    feasiIndex=find(Stat_All(:,2)==0);
    Best = min(Stat_All(:,1));
    Median = median(Stat_All(:,1));
    c = median(Stat_All(:,3))*100+median(Stat_All(:,4))*10+median(Stat_All(:,5));
    v_bar=median(Stat_All(:,2));
    Mean=mean(Stat_All(:,1));
    Worst = max(Stat_All(:,1));
    Std = std(Stat_All(:,1));
    SR=length(feasiIndex)/25;
    vio_bar=mean(Stat_All(:,2));
    
   
    oneStatistic = [Best;Median;c;v_bar;Mean;Worst;Std;SR;vio_bar];
    oneStatistic(find(abs(oneStatistic)<0.000001))=0;
    statistic(:,func) =  oneStatistic;
    bestF(:,func) = Stat_All(:,1);
    bestC(:,func) = Stat_All(:,2); 
end 
    xlswrite(['SASS-AP_temp_2017_',num2str(Dim),'D_statistic.xlsx'],statistic);
    xlswrite(['SASS-AP_temp_2017_',num2str(Dim),'D.xlsx'], bestF,1);
    xlswrite(['SASS-AP_temp_2017_',num2str(Dim),'D.xlsx'], bestC,2);
end