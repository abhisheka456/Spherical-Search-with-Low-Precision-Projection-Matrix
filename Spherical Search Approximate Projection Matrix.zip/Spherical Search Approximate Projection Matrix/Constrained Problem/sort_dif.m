function ind = sort_dif(fit1, cons1, fit2, cons2)
diff_fit = fit1-fit2;
diff_cons = cons1-cons2;
diff_fit = diff_fit(:);
diff_cons = diff_cons(:);
kk = find(diff_cons == 0);
ll = find(diff_cons < 0);
hh = find(diff_cons > 0);
ind = [];
[~,tt] = sort(-diff_cons(hh));
ind = [ind;hh(tt)];
[~,tt] = sort(-diff_fit(kk));
ind = [ind; kk(tt)];
[~,tt] = sort(-diff_cons(ll));
ind = [ind; ll(tt)];
end