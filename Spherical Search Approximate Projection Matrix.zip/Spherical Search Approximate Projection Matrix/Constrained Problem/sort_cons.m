function ind = sort_cons(fit, cons, VAR)
fit = fit(:);
cons = cons(:);
kk = find(max(0,cons-VAR) == 0);
hh = find(max(0,cons-VAR) > 0);
ind = [];
if isempty(kk)
else
[~,tt] = sort(fit(kk));
ind = kk(tt); 
end
[~,tt] = sort(max(0,cons(hh)-VAR));
ind = [ind; hh(tt)];
end