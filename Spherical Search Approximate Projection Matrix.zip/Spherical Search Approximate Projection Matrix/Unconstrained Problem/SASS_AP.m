%% START FROM here
%% Self-Adaptive Spherical Search with A Low Precision Projection Matrix 
%%                for Real-WorldOp timization
%%    Abhishek Kumar, Swagatam Das, Lingping Kong, and Vaclav Snasel
%% -----------------------------------------------------------------------
clc;
clear all;
pp = [10,30,50,100];
%% Loop for different dimension problems
for jj = 1:4
FF = zeros(51,30);
format long;
format compact;
Dim = pp(jj);
Max_NFES = 10000 * Dim;
val_2_reach = 10^(-8);
Max_Region = 100.0;
Min_Region = -100.0;
LU = [-100 * ones(1, Dim); 100 * ones(1, Dim)];
fhd=@cec17_func;
pb = 0.4;
ps = 0.5;
num_prbs = 30;
runs = 51;
run_funcvals = [];
RecordFEc_iactor = ...
    [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, ...
    0.5, 0.6, 0.7, 0.8, 0.9, 1.0];
progress = numel(RecordFEc_iactor);
allerrorvals = zeros(progress, runs, num_prbs);
result=zeros(num_prbs,5);
fprintf('Running SASS-AP on D= %d\n', Dim)
%% Loop for different problems
for func = [1 3: num_prbs]
    Optm = func * 100.0;
    outcome = [];
    fprintf('\n-------------------------------------------------------\n')
    fprintf('Function = %d, Dimension size = %d\n', func, Dim)
    for run_id = 1 : runs
        rand('seed',run_id*sum(100*clock));
        run_funcvals = [];
        col=1;             
        %%  parameter settings for SASS
        Pmax = 0.25;
        Pbest_Rate = Pmax;    
        Arc_Rate = 1.4;
        Mem_Size = 5;
        Pop_Size =floor( 25*log(Dim)*sqrt(Dim));
        SEL = round(ps*Pop_Size);
        Max_Pop_Size = Pop_Size;
        Min_Pop_Size = 4.0;
        G_Max = ceil(log(Min_Pop_Size/Max_Pop_Size)/log(1+(Min_Pop_Size-Max_Pop_Size)/Max_NFES));
        NFES = 0;
        %% Initialize the main population
        popold = repmat(LU(1, :), Pop_Size, 1) + rand(Pop_Size, Dim) .* (repmat(LU(2, :) - LU(1, :), Pop_Size, 1));
        pop = popold; 
        Fitt = feval(fhd,pop',func);
        Fitt = Fitt';
        bc_i_fit_var = 1e+30;
        bc_i_index = 0;
        bc_i_solution = zeros(1, Dim);
        for i = 1 : Pop_Size
            NFES = NFES + 1;
            if Fitt(i) < bc_i_fit_var
                bc_i_fit_var = Fitt(i);
                bc_i_solution = pop(i, :);
                bc_i_index = i;
            end
            if NFES > Max_NFES; break; end
        end
        Mem_c = 0.3 .* ones(Mem_Size, 1);
        Mem_r = 0.8 .* ones(Mem_Size, 1);
        
        Mem_Pos = 1;
        
        Arch.NP = Arc_Rate * Pop_Size; % the maximum size of the Arch
        Arch.pop = zeros(0, Dim); % the soLUtions stored in te Arch
        Arch.funvalues = zeros(0, 1); % the function value of the Archd soLUtions
        
        %% main loop
        gg=0;  
        igen =1;  
        
        flag1 = false;
        flag2 = false;
        while NFES < Max_NFES
            gg = gg+1;
            n = floor(Pop_Size/2);
            pop = popold; 
            [temp_fit, sorted_index] = sort(Fitt, 'ascend');
            ks = sorted_index(1:n);
            Mem_Rand_IDX = ceil(Mem_Size * rand(Pop_Size, 1));
            MU_c = Mem_c(Mem_Rand_IDX);
            MU_r = Mem_r(Mem_Rand_IDX);
            
            PPOS = find(Mem_Rand_IDX==Mem_Size);
            MU_c(PPOS) = 0.9;
            MU_r(PPOS) = 0.9;
            %%
            r_i = MU_r + 0.1*randn(Pop_Size, 1);
            term_pos = find(MU_r < -1);
            r_i(term_pos) = 0;
            r_i = min(r_i, 1);
            r_i = max(r_i, 0);

            if(NFES <= Max_NFES/2)
                if rand < 0.5
                    c_i = 0.5*ones(Pop_Size,1);
                else
                    c_i = 0.1*rand(Pop_Size,1)+0.45;
                end
            else
            c_i = MU_c + 0.1 * tan(pi * (rand(Pop_Size, 1) - 0.5));
            pos = find(c_i <= 0);
            
            while ~ isempty(pos)
                c_i(pos) = MU_c(pos) + 0.1 * tan(pi * (rand(length(pos), 1) - 0.5));
                pos = find(c_i <= 0);
            end
            c_i = min(c_i, 1);
            end
            c_i = min(c_i, 1);
            if NFES < 0.6*Max_NFES
               c_i = min(c_i,0.6*exp((NFES/Max_NFES).^3.5));
            end
            r0 = [1 : Pop_Size];
            popAll = [pop; Arch.pop];
            [r1, r2, r3] = gnR1R2(Pop_Size, size(popAll, 1), r0);
            
            pNP = max(round(Pbest_Rate * Pop_Size), 2);
            randindex = ceil(rand(1, Pop_Size) .* pNP);
            randindex = max(1, randindex); 
            pbest = pop(sorted_index(randindex), :);

            if NFES < 0.4*Max_NFES
                scc = 0.6*exp(6*(NFES/Max_NFES).^3);
            else
                scc = 1.2;
            end
            tep = pbest;
            tep(ks,:)= pop(r3(ks),:);
            vi = pop(r0,:) + c_i(:, ones(1, Dim)) .* (scc.*(tep - pop(r0,:)) + pop(r1, :) - popAll(r2, :));
            vi = boundConstraint(vi, pop, LU);
                 
            II = eye(Dim);
            TM = II+1e-4*randn(Dim);
            PP = TM'./(norm(TM,1)*norm(TM,inf));
            for k = 1:3
                PP= PP*((TM*PP-2*II)*(TM*PP-II)+II);
            end
            TM_ = PP;
            Xr = pop*TM;
            vi = vi*TM;
            Ur = Xr;
            nn = size(Xr,2);
            J_= mod(floor(rand(Pop_Size, 1)*nn), nn) + 1;
            J = (J_-1)*Pop_Size + (1:Pop_Size)';
            r_is = rand(Pop_Size, nn) < r_i(:, ones(1, nn));
            Ur(J) = vi(J);
            Ur(r_is) = vi(r_is);
            ui = Ur*TM_;

            Trail_Fitt = feval(fhd, ui', func);
            Trail_Fitt = Trail_Fitt';
            
            
            %% To check stagnation
            flag = false;
            bc_i_fit_var_old = bc_i_fit_var;
            for i = 1 : Pop_Size
                NFES = NFES + 1;
                
                if Trail_Fitt(i) < bc_i_fit_var
                    bc_i_fit_var = Trail_Fitt(i);
                    bc_i_solution = ui(i, :);
                    bc_i_index = i;
                end
                
                if NFES > Max_NFES; break; end
            end
            
            dif = abs(Fitt - Trail_Fitt);
            
            
            %% I == 1: the parent is better; I == 2: the offspring is better
            I = (Fitt > Trail_Fitt);
            goodr_i = r_i(I == 1);
            goodF = c_i(I == 1);
            dif_val = dif(I == 1);
            Arch = updateArch(Arch, popold(I == 1, :), Fitt(I == 1));
            [Fitt, I] = min([Fitt, Trail_Fitt], [], 2);
            popold = pop;
            popold(I == 2, :) = ui(I == 2, :);

            num_success_params = numel(goodr_i);
            
            if num_success_params > 0
                sum_dif = sum(dif_val);
                dif_val = dif_val / sum_dif;
                Mem_c(Mem_Pos) = ((dif_val' * (goodF .^ 2)) / (dif_val' * goodF)+Mem_c(Mem_Pos))*0.5;
                if max(goodr_i) == 0 || Mem_r(Mem_Pos)  == -1
                    Mem_r(Mem_Pos)  = -1;
                else
                    Mem_r(Mem_Pos) = ((dif_val' * (goodr_i .^ 2)) / (dif_val' * goodr_i)+Mem_r(Mem_Pos))*0.5;
                end
                Mem_Pos = Mem_Pos + 1;
                if Mem_Pos > Mem_Size;  Mem_Pos = 1; end
            end
            
            %% for resizing the population size
            plan_Pop_Size = round((((Min_Pop_Size - Max_Pop_Size) / Max_NFES) * NFES) + Max_Pop_Size);
            
            if Pop_Size > plan_Pop_Size
                reduction_ind_num = Pop_Size - plan_Pop_Size;
                if Pop_Size - reduction_ind_num <  Min_Pop_Size; reduction_ind_num = Pop_Size - Min_Pop_Size;end
                
                Pop_Size = Pop_Size - reduction_ind_num;
                SEL = round(ps*Pop_Size);
                for r = 1 : reduction_ind_num
                    [valBest indBest] = sort(Fitt, 'ascend');
                    worst_ind = indBest(end);
                    popold(worst_ind,:) = [];
                    pop(worst_ind,:) = [];
                    Fitt(worst_ind,:) = [];
                end
                
                Arch.NP = round(Arc_Rate * Pop_Size);
                
                if size(Arch.pop, 1) > Arch.NP
                    rndpos = randperm(size(Arch.pop, 1));
                    rndpos = rndpos(1 : Arch.NP);
                    Arch.pop = Arch.pop(rndpos, :);
                end
            end
            %% update Pbest_Rate
            Pbest_Rate = Pmax*(1 - 0.5*NFES/Max_NFES);
            if std(Fitt) < 1e-8 && min(Fitt-Optm) > 1e-3
                popold = repmat(LU(1, :), Pop_Size, 1) + rand(Pop_Size, Dim) .* (repmat(LU(2, :) - LU(1, :), Pop_Size, 1));
                pop = popold; 
                popold2 = repmat(LU(1, :), Pop_Size, 1) + rand(Pop_Size, Dim) .* (repmat(LU(2, :) - LU(1, :), Pop_Size, 1));
                Fitt = feval(fhd,pop',func);
                Fitt = Fitt';
            end
%%
            if Dim == 10
               Np = 100;
               LM_NFES = 4950;
               fitlim = 1e1;
            elseif Dim == 30
               Np = 300;
               LM_NFES = 44850;
               fitlim = 1e1;
            elseif Dim == 50
               Np = 500;
               LM_NFES = 124750;
               fitlim = 2e1;
            else
               Np = 500;
               LM_NFES = 124750;
               fitlim = 1e2;
            end
            if Dim > 0 && LM_NFES > Max_NFES - NFES && (bc_i_fit_var-100*func) > fitlim
               xmean = mean(pop);
               xstd  = std(pop);
               total = Np;
               mu    = floor(0.8*total);
               weights=log(mu+1/2)-log(1:mu)';
               weights=weights/sum(weights);
               kk = 0;
               cc = 0;
               xmin = zeros(10000,1);
               while NFES < Max_NFES
                    kk = kk+1;
                    if kk>30 
                       if mod(kk,20)==0
                          [aaa,bbb]=min(xmin(1:kk));
                          if bbb<kk-20
                             cc = 1;
                          else
                             cc = 0;
                          end
                       end
                    end
                    if cc == 1
                       XX = xmean(ones(total,1),:)+0.96*randn(total,Dim).*xstd(ones(total,1),:);
                    else
                       XX = xmean(ones(total,1),:)+randn(total,Dim).*xstd(ones(total,1),:);
                    end
                    for k=1:total
                        for j=1:Dim
                            if XX(k,j)>100 
                               XX(k,j)=xmean(j)+xstd(j).*randn(1,1);
                            elseif XX(k,j)<-100
                               XX(k,j)=xmean(j)+xstd(j).*randn(1,1);
                            end
                        end
                    end
                    xFitt = feval(fhd, XX', func);
                    NFES = NFES + total;
                    xmin(kk) = min(xFitt);
                    [~,ind] = sort(xFitt);
                    xmean = (XX(ind(1:mu),:)'*weights)';
                    xstd = std(XX(ind(1:mu),:));
                    if xFitt(ind(1)) < bc_i_fit_var
                       bc_i_fit_var = xFitt(ind(1));
                       bc_i_solution = XX(ind(1), :);
                       bc_i_index = i;
                    end
%                     disp(bc_i_fit_var-100*func)
                    total = floor(0.999*total);
                    mu    = floor(0.8*total);
                    weights=log(mu+1/2)-log(1:mu)';
                    weights=weights/sum(weights);
                    if total < 2
                       break;
                    end
               end
            end
        end 
        
        bc_i_error_val = bc_i_fit_var - Optm;
        if bc_i_error_val < val_2_reach
            bc_i_error_val = 0;
        end
        FF(run_id,func) = bc_i_error_val;
        fprintf('%d th run, best-so-far error value = %1.8e\n', run_id , bc_i_error_val)
        outcome = [outcome bc_i_error_val];  
    end %% end 1 run
    
    fprintf('\n')
    fprintf('min error value = %1.8e, max = %1.8e, median = %1.8e, mean = %1.8e, std = %1.8e\n', min(outcome), max(outcome), median(outcome), mean(outcome), std(outcome))
    
    result(func,1)=  min(outcome);
    result(func,2)=  max(outcome);
    result(func,3)=  median(outcome);
    result(func,4)=  mean(outcome);
    result(func,5)=  std(outcome);
    
end %% end 1 function run
xlswrite('SASS_approx_norm.xlsx',FF,jj);
disp(result);

name1 = 'results_stat_';
name2 = num2str(Dim);
name3 = '.txt';
f_name=strcat(name1,name2,name3);

save(f_name, 'result', '-ascii');

end