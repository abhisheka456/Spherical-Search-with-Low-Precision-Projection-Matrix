clc;
clear all;

Result_10=[];
Result_30=[];
Result_50=[];
Result_100=[];




for c= 1:7
 
    
    if c == 1
        eva = 'SASS_approx_norm.xlsx';
    elseif c == 2
        eva = 'SASS_approx_norm_without_ls.xlsx';
    elseif c == 3
        eva = 'Lshade_rsp.xlsx';
    elseif c == 4
        eva = 'jSO.xlsx';
    elseif c == 5
        eva = 'HSES.xlsx';
    elseif c == 6
        eva = 'ELshade_rsp.xlsx';
    elseif c == 7
        eva = 'EBOwithCMAR.xlsx';
    end
        data1 = xlsread(eva,1);
        data2 = xlsread(eva,2);
        data3 = xlsread(eva,3);
        data4 = xlsread(eva,4);
    Result_10=[Result_10,mean(data1)'];  % means for all algs ordered on 10D 
    Result_30=[Result_30,mean(data2)'];  % means for all algs ordered on 30D 
    Result_50=[Result_50,mean(data3)'];  % means for all algs ordered on 50D 
    Result_100=[Result_100,mean(data4)']; % means for all algs ordered on 100D 
end

% Remove F2
Result_10(2,:)=[];
Result_30(2,:)=[];
Result_50(2,:)=[];
Result_100(2,:)=[];

%% Compute score 1
SE_10=sum(Result_10);
SE_30=sum(Result_30);
SE_50=sum(Result_50);
SE_100=sum(Result_100);

SE=SE_10.*0.1+SE_30.*0.2+SE_50.*0.3+SE_100.*0.4;
S1=(1-(SE-min(SE))./SE)*50;
%%

%% Compute Score 2
for i = 1:29
    rank_10(i,:)=tiedrank(Result_10(i,:));
    rank_30(i,:)=tiedrank(Result_30(i,:));
    rank_50(i,:)=tiedrank(Result_50(i,:));
    rank_100(i,:)=tiedrank(Result_100(i,:));
   
end

sum_rank_10=sum(rank_10);
sum_rank_30=sum(rank_30);
sum_rank_50=sum(rank_50);
sum_rank_100=sum(rank_100);

SR=sum_rank_10.*0.1+sum_rank_30.*0.2+sum_rank_50.*0.3+sum_rank_100.*0.4;

S2=(1-(SR-min(SR))./SR)*50;
%%

%% Compute total score
S=S1+S2;
R=tiedrank(100-S);
format short
disp([S1',S2',S',R'])
data = [S1',S2',S',R'];





