%% statistical Test
clc;
clear all
for i = 1
    if i == 1
        eva = 'SASS_approx_norm.xlsx';
    elseif i == 2
        eva = 'SASS_approx_tri_rand.xlsx';
    end
        data11 = xlsread(eva,1);
        data12 = xlsread(eva,2);
        data13 = xlsread(eva,3);
        data14 = xlsread(eva,4);
        result_10 = [];
        result_30 = [];
        result_50 = [];
        result_100 = [];
        wt_10 = [];
        wt_30 = [];
        wt_50 = [];
        wt_100 = [];
for c= i+1:7
 
    
    if c == 1
        eva = 'SASS_approx_norm.xlsx';
    elseif c == 2
        eva = 'SASS_approx_norm_without_ls.xlsx';
    elseif c == 3
        eva = 'Lshade_rsp.xlsx';
    elseif c == 4
        eva = 'jSO.xlsx';
    elseif c == 5
        eva = 'HSES.xlsx';
    elseif c == 6
        eva = 'ELshade_rsp.xlsx';
    elseif c == 7
        eva = 'EBOwithCMAR.xlsx';
    end
        data1 = xlsread(eva,1);
        data2 = xlsread(eva,2);
        data3 = xlsread(eva,3);
        data4 = xlsread(eva,4);
    [wt1, state1] = signedranktest(data11,data1);
    [wt2, state2] = signedranktest(data12,data2);
    [wt3, state3] = signedranktest(data13,data3);
    [wt4, state4] = signedranktest(data14,data4);
    %% for 10D
    result_10 = [ result_10;state1];
    result_30 = [ result_30;state2];
    result_50 = [ result_50;state3];
    result_100 = [ result_100;state4];
    wt_10 = [wt_10, wt1];
    wt_30 = [wt_30, wt2];
    wt_50 = [wt_50, wt3];
    wt_100 = [wt_100, wt4];
end
eva = ['LASS_10_' num2str(i) '=result_10;']; eval(eva);
eva = ['LASS_30_' num2str(i) '=result_30;']; eval(eva);
eva = ['LASS_50_' num2str(i) '=result_50;']; eval(eva);
eva = ['LASS_100_' num2str(i) '=result_100;']; eval(eva);
end