%% statistical Test
clc;
clear all
        result_10 = [];
        result_30 = [];
        result_50 = [];
        result_100 = [];
for c= 1:7
 
    
    if c == 1
        eva = 'SASS_approx_norm.xlsx';
    elseif c == 2
        eva = 'SASS_approx_norm_without_ls.xlsx';
    elseif c == 3
        eva = 'Lshade_rsp.xlsx';
    elseif c == 4
        eva = 'jSO.xlsx';
    elseif c == 5
        eva = 'HSES.xlsx';
    elseif c == 6
        eva = 'ELshade_rsp.xlsx';
    elseif c == 7
        eva = 'EBOwithCMAR.xlsx';
    end
        data1 = xlsread(eva,1);data1(:,2) = [];
        data2 = xlsread(eva,2);data2(:,2) = [];
        data3 = xlsread(eva,3);data3(:,2) = [];
        data4 = xlsread(eva,4);data4(:,2) = [];
    %% for 10D
    result_10 = [ result_10,mean(data1)',std(data1)'];
    result_30 = [ result_30,mean(data2)',std(data2)'];
    result_50 = [ result_50,mean(data3)',std(data3)'];
    result_100 = [ result_100,mean(data4)',std(data4)'];
end
i = 2*(1:c)-1;
T_10 = myfriedman(result_10(:,i))/29; [~,I_10] = sort(result_10(:,i),2);
T_30 = myfriedman(result_30(:,i))/29; [~,I_30] = sort(result_30(:,i),2);
T_50 = myfriedman(result_50(:,i))/29; [~,I_50] = sort(result_50(:,i),2);
T_100 = myfriedman(result_100(:,i))/29; [~,I_100] = sort(result_100(:,i),2);
